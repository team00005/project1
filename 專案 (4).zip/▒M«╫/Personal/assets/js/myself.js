var checkEye = document.getElementById("checkEye");
var floatingPassword =  document.getElementById("passwordset1");
checkEye.addEventListener("click", function(e){
  if(e.target.classList.contains('fa-eye')){
  //換class 病患 type
    e.target.classList.remove('fa-eye');
    e.target.classList.add('fa-eye-slash');
    floatingPassword.setAttribute('type','text')
  }else{
    floatingPassword.setAttribute('type','password');
    e.target.classList.remove('fa-eye-slash');
    e.target.classList.add('fa-eye')
  }
});

/**
   * signup-page-password
   */

function checkPass(){
  var pwd1=document.getElementById("passwordset1").value;
  var pwd2=document.getElementById("passwordset2").value;
  if(pwd1!=pwd2){
  document.getElementById("errorpassword").style.display = "block";
  document.getElementById("correctpassword").style.display = "none";
  return false;
  }else{
    document.getElementById("correctpassword").style.display = "block";
    document.getElementById("errorpassword").style.display = "none";
    return true;
  }
}